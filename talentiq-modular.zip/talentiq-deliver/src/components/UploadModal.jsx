// src/components/UploadModal.jsx
import { useState, useRef } from "react";
import { C } from "../theme";
import { readExcelFile } from "../utils/excel";

function UploadSlot({ icon, title, description, file, onFile, status }) {
  const ref = useRef();
  const [dr, setDr] = useState(false);
  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDr(true); }}
      onDragLeave={() => setDr(false)}
      onDrop={(e) => { e.preventDefault(); setDr(false); const f = e.dataTransfer.files[0]; if (f) onFile(f); }}
      onClick={() => ref.current?.click()}
      style={{
        border: `1.5px dashed ${file ? C.teal400 : dr ? C.teal500 : C.slate300}`,
        borderRadius: 10, padding: "20px", cursor: "pointer",
        background: file ? C.teal50 : C.slate50,
      }}
    >
      <input
        ref={ref} type="file" accept=".xlsx,.xls,.csv" style={{ display: "none" }}
        onChange={(e) => { const f = e.target.files[0]; if (f) onFile(f); }}
      />
      <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
        <div style={{ fontSize: 28, lineHeight: 1 }}>{icon}</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: C.slate800, marginBottom: 3 }}>{title}</div>
          <div style={{ fontSize: 11, color: C.slate500, lineHeight: 1.5, marginBottom: 8 }}>{description}</div>
          {!file && <div style={{ fontSize: 11, color: C.teal600, fontWeight: 500 }}>Click or drag file here</div>}
          {file && (
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ width: 7, height: 7, borderRadius: "50%", background: status === "error" ? C.red : "#22C55E", display: "inline-block" }} />
              <span style={{ fontSize: 12, fontWeight: 500, color: C.slate800 }}>{file.name}</span>
              <span style={{ fontSize: 10, color: C.slate400 }}>{file.rows != null ? `${file.rows} rows` : ""}</span>
              <button
                onClick={(e) => { e.stopPropagation(); onFile(null); }}
                style={{ marginLeft: "auto", background: "none", border: "none", color: C.slate400, cursor: "pointer", fontSize: 14 }}
              >&times;</button>
            </div>
          )}
          {status === "error" && <div style={{ fontSize: 11, color: C.red, marginTop: 4 }}>Failed to parse.</div>}
        </div>
      </div>
    </div>
  );
}

export default function UploadModal({ onClose, onData }) {
  const [taFile, setTaFile] = useState(null);
  const [msdFile, setMsdFile] = useState(null);
  const [benchFile, setBenchFile] = useState(null);
  const [taS, setTaS] = useState(null);
  const [msdS, setMsdS] = useState(null);
  const [benchS, setBenchS] = useState(null);

  const handleFile = async (file, setter, statusSetter) => {
    if (!file) { setter(null); statusSetter(null); return; }
    statusSetter("parsing");
    try {
      const parsed = await readExcelFile(file);
      setter({ name: file.name, rows: parsed.rowCounts.reduce((a, b) => a + b, 0), parsed });
      statusSetter("success");
    } catch (err) {
      console.error(err);
      setter({ name: file.name });
      statusSetter("error");
    }
  };

  const any = (taFile && taS === "success") || (msdFile && msdS === "success") || (benchFile && benchS === "success");

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", zIndex: 1000,
        display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(2px)",
      }}
    >
      <div onClick={(e) => e.stopPropagation()} style={{ background: C.white, borderRadius: 14, width: 620, maxHeight: "90vh", overflow: "auto", padding: 32 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.slate800 }}>Upload Weekly Data</div>
            <div style={{ fontSize: 12, color: C.slate400, marginTop: 2 }}>Upload files to refresh dashboard & skill mapping</div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 22, color: C.slate400, cursor: "pointer" }}>&times;</button>
        </div>

        <div style={{ display: "flex", gap: 8, margin: "18px 0 20px" }}>
          {[
            { n: 1, l: "TA Data", d: taS === "success" },
            { n: 2, l: "MSD Allocation", d: msdS === "success" },
            { n: 3, l: "Bench IDs", d: benchS === "success" },
          ].map((s) => (
            <div key={s.n} style={{ flex: 1, textAlign: "center" }}>
              <div style={{
                width: 28, height: 28, borderRadius: "50%", margin: "0 auto 4px",
                display: "flex", alignItems: "center", justifyContent: "center",
                background: s.d ? C.teal600 : C.slate200,
                color: s.d ? C.white : C.slate500,
                fontSize: 12, fontWeight: 600,
              }}>{s.d ? "✓" : s.n}</div>
              <div style={{ fontSize: 10, color: s.d ? C.teal700 : C.slate400, fontWeight: 500 }}>{s.l}</div>
            </div>
          ))}
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 20 }}>
          <UploadSlot
            icon="📊" title="Talent Acquisition Data"
            description="Req_Upload sheet — Status, Country, Age, Client_Name, Primary_Skill_1, L3_Skills, Grade"
            file={taFile} status={taS}
            onFile={(f) => handleFile(f, setTaFile, setTaS)}
          />
          <UploadSlot
            icon="📋" title="MSD Allocation List"
            description="Employee allocations — Skillsets, L3/L4 Skills, Grade, Bench Ageing, Onshore/Offshore"
            file={msdFile} status={msdS}
            onFile={(f) => handleFile(f, setMsdFile, setMsdS)}
          />
          <UploadSlot
            icon="👥" title="Bench Resource IDs"
            description="Employee Id column — filters MSD to identify bench resources for skill mapping"
            file={benchFile} status={benchS}
            onFile={(f) => handleFile(f, setBenchFile, setBenchS)}
          />
        </div>

        <div style={{ background: C.teal50, border: `1px solid ${C.teal200}`, borderRadius: 8, padding: 14, marginBottom: 18 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: C.teal800, marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.8 }}>Data Flow</div>
          <div style={{ fontSize: 11, color: C.teal700, lineHeight: 1.7 }}>
            <div>• TA Data → Dashboard + Open positions for mapping</div>
            <div>• MSD + Bench IDs → Bench resources with skills, grade, tenure</div>
            <div>• Grade: A → 2A → 3A → 3B → 4A → 4B → 5A → 5B → 6A...</div>
          </div>
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={onClose} style={{
            flex: 1, padding: "12px 0", borderRadius: 8,
            border: `1px solid ${C.slate300}`, background: C.white, color: C.slate600,
            fontSize: 13, fontWeight: 500, cursor: "pointer", fontFamily: "inherit",
          }}>Cancel</button>
          <button
            onClick={() => {
              onData({
                taSheets: taFile?.parsed?.sheets,
                msdSheets: msdFile?.parsed?.sheets,
                benchSheets: benchFile?.parsed?.sheets,
              });
              onClose();
            }}
            disabled={!any}
            style={{
              flex: 2, padding: "12px 0", borderRadius: 8, border: "none",
              background: any ? C.teal600 : C.slate200,
              color: any ? C.white : C.slate400,
              fontSize: 13, fontWeight: 600,
              cursor: any ? "pointer" : "not-allowed", fontFamily: "inherit",
            }}
          >Apply Data</button>
        </div>
      </div>
    </div>
  );
}
